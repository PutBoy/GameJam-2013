walk around with 
W A S D
pickup weapons with space
attack with left arrow